import administrative_window


def fun_back_from_add_course(admin_name):
    administrative_window.administrative_window(admin_name)


def fun_back_from_remove_course(admin_name):
    administrative_window.administrative_window(admin_name)
