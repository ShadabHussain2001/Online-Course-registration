# online-e-learning-system-using-tkinter
Created as part of my mini project
It is a GUI that has created using GUI tkinter and modules like smtplib.
